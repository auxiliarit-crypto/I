const palette = 'slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose';
const shades = '50|100|200|300|400|500|600|700|800|900|950';

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}', './node_modules/@tremor/**/*.{js,ts,jsx,tsx}'],
  theme: {
    transparent: 'transparent',
    current: 'currentColor',
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '"Segoe UI"', 'Roboto', 'Helvetica', 'Arial', 'sans-serif'],
      },
      colors: {
        ink: { DEFAULT: '#0b1020', 800: '#111833', 700: '#1a2347' },
        tremor: {
          brand: { faint: '#eef2ff', muted: '#c7d2fe', subtle: '#818cf8', DEFAULT: '#4f46e5', emphasis: '#3730a3', inverted: '#ffffff' },
          background: { muted: '#f8fafc', subtle: '#f1f5f9', DEFAULT: '#ffffff', emphasis: '#334155' },
          border: { DEFAULT: '#e2e8f0' },
          ring: { DEFAULT: '#e2e8f0' },
          content: { subtle: '#94a3b8', DEFAULT: '#64748b', emphasis: '#334155', strong: '#0f172a', inverted: '#ffffff' },
        },
      },
      boxShadow: {
        soft: '0 1px 2px rgba(16,24,40,0.04), 0 4px 16px -4px rgba(16,24,40,0.07)',
        lift: '0 2px 4px rgba(16,24,40,0.05), 0 12px 32px -8px rgba(16,24,40,0.14)',
        'tremor-input': '0 1px 2px 0 rgb(0 0 0 / 0.05)',
        'tremor-card': '0 1px 2px rgba(16,24,40,0.04), 0 4px 16px -4px rgba(16,24,40,0.07)',
        'tremor-dropdown': '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
      },
      borderRadius: {
        'tremor-small': '0.5rem',
        'tremor-default': '0.75rem',
        'tremor-full': '9999px',
      },
      fontSize: {
        'tremor-label': ['0.75rem', { lineHeight: '1rem' }],
        'tremor-default': ['0.875rem', { lineHeight: '1.25rem' }],
        'tremor-title': ['1.125rem', { lineHeight: '1.75rem' }],
        'tremor-metric': ['1.875rem', { lineHeight: '2.25rem' }],
      },
      keyframes: {
        rise: { '0%': { opacity: 0, transform: 'translateY(8px)' }, '100%': { opacity: 1, transform: 'translateY(0)' } },
      },
      animation: { rise: 'rise .35s ease-out both' },
    },
  },
  safelist: ['bg', 'text', 'border', 'ring', 'stroke', 'fill'].map((prefix) => ({
    pattern: new RegExp(`^${prefix}-(${palette})-(${shades})$`),
    variants: ['hover', 'ui-selected'],
  })),
  plugins: [require('@headlessui/tailwindcss'), require('@tailwindcss/forms')],
};
