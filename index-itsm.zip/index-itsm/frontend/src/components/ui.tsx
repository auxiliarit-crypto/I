import type { ReactNode } from 'react';

const STATUS: Record<string, { dot: string; cls: string }> = {
  Abierto: { dot: 'bg-rose-500', cls: 'bg-rose-50 text-rose-700 ring-rose-200' },
  'En progreso': { dot: 'bg-amber-500', cls: 'bg-amber-50 text-amber-700 ring-amber-200' },
  Resuelto: { dot: 'bg-sky-500', cls: 'bg-sky-50 text-sky-700 ring-sky-200' },
  Cerrado: { dot: 'bg-emerald-500', cls: 'bg-emerald-50 text-emerald-700 ring-emerald-200' },
};

const PRIORITY: Record<string, { dot: string; cls: string }> = {
  Alta: { dot: 'bg-red-500', cls: 'bg-red-50 text-red-700 ring-red-200' },
  Media: { dot: 'bg-amber-500', cls: 'bg-amber-50 text-amber-700 ring-amber-200' },
  Baja: { dot: 'bg-slate-400', cls: 'bg-slate-100 text-slate-600 ring-slate-200' },
};

export function Chip({ children, cls, dot }: { children: ReactNode; cls: string; dot?: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${cls}`}>
      {dot && <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />}
      {children}
    </span>
  );
}

export const StatusChip = ({ status }: { status: string }) => (
  <Chip cls={STATUS[status]?.cls || ''} dot={STATUS[status]?.dot}>{status}</Chip>
);

export const PriorityChip = ({ priority }: { priority: string }) => (
  <Chip cls={PRIORITY[priority]?.cls || ''} dot={PRIORITY[priority]?.dot}>{priority}</Chip>
);

const AVATAR_COLORS = ['bg-indigo-500', 'bg-violet-500', 'bg-sky-500', 'bg-emerald-500', 'bg-rose-500', 'bg-amber-500', 'bg-teal-500'];

export function Avatar({ name, size = 36 }: { name: string; size?: number }) {
  const initials = name.split(/[\s._-]+/).filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join('') || '?';
  const color = AVATAR_COLORS[[...name].reduce((a, c) => a + c.charCodeAt(0), 0) % AVATAR_COLORS.length];
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center rounded-full font-semibold text-white ${color}`}
      style={{ width: size, height: size, fontSize: size * 0.38 }}
    >
      {initials}
    </span>
  );
}

export const fmtDate = (d?: string | null) =>
  d ? new Date(d).toLocaleString('es-GT', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';

export const fmtFull = (d?: string | null) => (d ? new Date(d).toLocaleString('es-GT') : '—');
