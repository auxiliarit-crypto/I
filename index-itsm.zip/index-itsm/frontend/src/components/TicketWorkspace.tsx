'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { io, Socket } from 'socket.io-client';
import {
  ArrowLeft, Eye, FileText, Loader2, Lock, MessageSquare, Paperclip, PenLine, Save, Send, Trash2, Upload, History, Settings2,
} from 'lucide-react';
import { API, api, getToken } from '@/lib/api';
import { getUser, User } from '@/lib/auth';
import AppShell from '@/components/AppShell';
import { Avatar, PriorityChip, StatusChip, fmtDate, fmtFull } from '@/components/ui';

type Viewer = { userId: string; name: string; typing: boolean; since: string };

const STATUSES = ['Abierto', 'En progreso', 'Resuelto', 'Cerrado'];
const PRIORITIES = ['Alta', 'Media', 'Baja'];
const MAX_FILES = 5;
const MAX_SIZE = 10 * 1024 * 1024;

const toForm = (t: any) => ({
  status: t.status,
  priority: t.priority,
  category_id: String(t.category_id),
  assigned_to: t.assigned_to ?? '',
  solution: t.solution ?? '',
  fcr: t.fcr,
  documented: t.documented,
  tags: (t.tags || []).join(', '),
  watchers: (t.watchers || []).map((w: any) => w.email).join(', '),
});

function SlaLine({ label, done, due, breached }: { label: string; done?: string | null; due?: string | null; breached: boolean }) {
  return (
    <div className="rounded-xl border border-slate-100 bg-slate-50/70 p-3">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold text-slate-600">{label}</p>
        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${breached ? 'bg-red-100 text-red-700' : done ? 'bg-emerald-100 text-emerald-700' : 'bg-indigo-100 text-indigo-700'}`}>
          {breached ? 'Vencido' : done ? 'Cumplido' : 'En curso'}
        </span>
      </div>
      <p className="mt-1.5 text-xs text-slate-500">Límite: <span className="font-medium text-slate-700">{fmtDate(due)}</span></p>
      <p className="text-xs text-slate-500">Registrado: <span className="font-medium text-slate-700">{fmtDate(done)}</span></p>
    </div>
  );
}

export default function TicketWorkspace({ ticketId, user }: { ticketId: number; user: User }) {
  const me = useMemo(() => getUser(), []);
  const canEdit = me?.role === 'agent';

  const [ticket, setTicket] = useState<any>(null);
  const [options, setOptions] = useState<{ categories: any[]; agents: any[] }>({ categories: [], agents: [] });
  const [form, setForm] = useState<any>(null);
  const [viewers, setViewers] = useState<Viewer[]>([]);
  const [tab, setTab] = useState(0);
  const [comment, setComment] = useState('');
  const [internal, setInternal] = useState(false);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const dirty = useRef(false);
  const typingTimer = useRef<any>(null);
  const socketRef = useRef<Socket | null>(null);

  const load = useCallback(async () => {
    try {
      const t = await api(`/api/tickets/${ticketId}`);
      setTicket(t);
      if (!dirty.current) setForm(toForm(t));
    } catch (e: any) {
      setError(e.message);
    }
  }, [ticketId]);

  useEffect(() => {
    load();
    api('/api/tickets/meta').then(setOptions).catch(() => {});
  }, [load]);

  useEffect(() => {
    const socket = io(API, { auth: { token: getToken() }, transports: ['websocket'] });
    socketRef.current = socket;
    socket.on('connect', () => socket.emit('ticket:view', { ticketId }));
    socket.on('presence:update', (p: { ticketId: number; viewers: Viewer[] }) => {
      if (p.ticketId === ticketId) setViewers(p.viewers);
    });
    socket.on('ticket:updated', (p: { ticketId: number }) => {
      if (p.ticketId === ticketId) load();
    });
    return () => {
      clearTimeout(typingTimer.current);
      socket.emit('ticket:leave', { ticketId });
      socket.disconnect();
    };
  }, [ticketId, load]);

  const others = viewers.filter((v) => v.userId !== me?.id);
  const othersTyping = others.filter((v) => v.typing);

  function setField(key: string, value: any) {
    dirty.current = true;
    setForm((f: any) => ({ ...f, [key]: value }));
  }

  function onCommentChange(value: string) {
    setComment(value);
    socketRef.current?.emit('ticket:typing', { ticketId, typing: value.length > 0 });
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => socketRef.current?.emit('ticket:typing', { ticketId, typing: false }), 3000);
  }

  async function sendComment() {
    if (!comment.trim()) return;
    setBusy(true);
    setMsg(null);
    try {
      const t = await api(`/api/tickets/${ticketId}/comments`, {
        method: 'POST',
        body: JSON.stringify({ body: comment, is_internal: internal }),
      });
      setTicket(t);
      if (!dirty.current) setForm(toForm(t));
      setComment('');
      socketRef.current?.emit('ticket:typing', { ticketId, typing: false });
    } catch (e: any) {
      setMsg({ type: 'err', text: e.message });
    } finally {
      setBusy(false);
    }
  }

  async function save() {
    setBusy(true);
    setMsg(null);
    try {
      const t = await api(`/api/tickets/${ticketId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status: form.status,
          priority: form.priority,
          category_id: Number(form.category_id),
          assigned_to: form.assigned_to,
          solution: form.solution,
          fcr: form.fcr,
          documented: form.documented,
          tags: form.tags.split(',').map((s: string) => s.trim()).filter(Boolean),
          watchers: form.watchers,
        }),
      });
      dirty.current = false;
      setTicket(t);
      setForm(toForm(t));
      setMsg({ type: 'ok', text: 'Cambios guardados correctamente' });
    } catch (e: any) {
      setMsg({ type: 'err', text: e.message });
    } finally {
      setBusy(false);
    }
  }

  async function upload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (!files.length) return;
    if (ticket.attachments.length + files.length > MAX_FILES) {
      return setMsg({ type: 'err', text: `Máximo ${MAX_FILES} adjuntos por ticket` });
    }
    const big = files.find((f) => f.size > MAX_SIZE);
    if (big) return setMsg({ type: 'err', text: `"${big.name}" supera los 10 MB` });

    const fd = new FormData();
    files.forEach((f) => fd.append('files', f));
    setBusy(true);
    setMsg(null);
    try {
      const t = await api(`/api/tickets/${ticketId}/attachments`, { method: 'POST', body: fd });
      setTicket(t);
      setMsg({ type: 'ok', text: 'Adjuntos cargados' });
    } catch (err: any) {
      setMsg({ type: 'err', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function removeAttachment(id: number) {
    if (!confirm('¿Eliminar este adjunto?')) return;
    try {
      await api(`/api/tickets/attachments/${id}`, { method: 'DELETE' });
      load();
    } catch (err: any) {
      setMsg({ type: 'err', text: err.message });
    }
  }

  if (error) return <AppShell user={user} title="Ticket"><p className="text-red-600">{error}</p></AppShell>;
  if (!ticket || !form) return <AppShell user={user} title="Ticket"><p className="text-slate-500">Cargando ticket…</p></AppShell>;

  const tabs = [
    { label: 'Conversación', icon: MessageSquare, badge: ticket.comments.length },
    { label: 'Detalles y cierre', icon: Settings2 },
    { label: 'Adjuntos', icon: Paperclip, badge: `${ticket.attachments.length}/${MAX_FILES}` },
    { label: 'Historial', icon: History },
  ];

  return (
    <AppShell
      user={user}
      wide
      title={`${ticket.code} · ${ticket.category}`}
      subtitle={`Reportado por ${ticket.requester_name} · ${fmtFull(ticket.created_at)}`}
      actions={
        <div className="flex flex-wrap items-center gap-2">
          <StatusChip status={ticket.status} />
          <PriorityChip priority={ticket.priority} />
          {!canEdit && <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600 ring-1 ring-inset ring-slate-200">Solo lectura</span>}
          <Link href="/tickets" className="btn-soft !py-2"><ArrowLeft size={16} /> Volver</Link>
        </div>
      }
    >
      {others.length > 0 && (
        <div className={`mb-5 flex items-start gap-3 rounded-2xl border p-4 ${othersTyping.length ? 'border-red-200 bg-red-50' : 'border-amber-200 bg-amber-50'}`}>
          <span className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${othersTyping.length ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'}`}>
            {othersTyping.length ? <PenLine size={18} /> : <Eye size={18} />}
          </span>
          <div>
            <p className={`text-sm font-semibold ${othersTyping.length ? 'text-red-800' : 'text-amber-900'}`}>
              {others.map((o) => o.name).join(', ')} {others.length > 1 ? 'están viendo' : 'está viendo'} este ticket
            </p>
            <p className={`mt-0.5 text-sm ${othersTyping.length ? 'text-red-700' : 'text-amber-800'}`}>
              {othersTyping.length
                ? `${othersTyping.map((o) => o.name).join(', ')} está escribiendo una respuesta. Coordine antes de responder para no duplicar acciones.`
                : 'Coordine antes de responder o cambiar el estado para evitar acciones duplicadas.'}
            </p>
          </div>
        </div>
      )}

      {msg && (
        <div className={`mb-5 rounded-xl px-4 py-3 text-sm font-medium ${msg.type === 'ok' ? 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200' : 'bg-red-50 text-red-700 ring-1 ring-red-200'}`}>
          {msg.text}
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
        <div className="card overflow-hidden">
          <div className="flex gap-1 overflow-x-auto border-b border-slate-100 px-3 pt-3">
            {tabs.map((t, i) => {
              const Icon = t.icon;
              return (
                <button
                  key={t.label}
                  onClick={() => setTab(i)}
                  className={`flex items-center gap-2 whitespace-nowrap rounded-t-xl border-b-2 px-4 py-3 text-sm font-medium transition ${
                    tab === i ? 'border-indigo-600 text-indigo-700' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Icon size={16} /> {t.label}
                  {t.badge !== undefined && (
                    <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${tab === i ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-500'}`}>{t.badge}</span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="p-6">
            {tab === 0 && (
              <div className="space-y-4">
                <div className="flex gap-3">
                  <Avatar name={ticket.requester_name} />
                  <div className="flex-1 rounded-2xl rounded-tl-sm border border-slate-200 bg-slate-50 p-4">
                    <p className="mb-1 text-xs text-slate-500"><strong className="text-slate-700">{ticket.requester_name}</strong> · {fmtDate(ticket.created_at)} · descripción original</p>
                    <p className="whitespace-pre-wrap text-sm text-slate-800">{ticket.description}</p>
                  </div>
                </div>

                {ticket.comments.map((c: any) => (
                  <div key={c.id} className="flex gap-3">
                    <Avatar name={c.author_name} />
                    <div className={`flex-1 rounded-2xl rounded-tl-sm border p-4 ${c.is_internal ? 'border-amber-200 bg-amber-50' : 'border-indigo-100 bg-indigo-50/60'}`}>
                      <p className="mb-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <strong className="text-slate-700">{c.author_name}</strong> · {fmtDate(c.created_at)}
                        {c.is_internal ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-amber-200/70 px-2 py-0.5 text-[10px] font-bold uppercase text-amber-800"><Lock size={10} /> Nota interna</span>
                        ) : (
                          <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-[10px] font-bold uppercase text-indigo-700">Pública</span>
                        )}
                      </p>
                      <p className="whitespace-pre-wrap text-sm text-slate-800">{c.body}</p>
                    </div>
                  </div>
                ))}

                {canEdit && (
                  <div className={`rounded-2xl border p-4 transition ${internal ? 'border-amber-200 bg-amber-50/60' : 'border-slate-200 bg-white'}`}>
                    <div className="mb-3 inline-flex rounded-xl bg-slate-100 p-1 text-sm font-medium">
                      <button onClick={() => setInternal(false)} className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 transition ${!internal ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-500'}`}>
                        <Send size={14} /> Respuesta pública
                      </button>
                      <button onClick={() => setInternal(true)} className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 transition ${internal ? 'bg-white text-amber-700 shadow-sm' : 'text-slate-500'}`}>
                        <Lock size={14} /> Nota interna
                      </button>
                    </div>
                    <textarea
                      rows={4}
                      value={comment}
                      onChange={(e) => onCommentChange(e.target.value)}
                      placeholder={internal ? 'Nota visible solo para IT y Gerencia…' : 'Mensaje que verá el usuario…'}
                      className="input"
                    />
                    <div className="mt-3 flex items-center justify-between">
                      <p className="text-xs text-slate-400">{internal ? 'El usuario no verá esta nota.' : 'El usuario recibirá esta respuesta en su portal.'}</p>
                      <button className="btn-primary" onClick={sendComment} disabled={busy || !comment.trim()}>
                        {busy ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                        {internal ? 'Guardar nota' : 'Enviar respuesta'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {tab === 1 && (
              <div className="space-y-5">
                <div className="grid gap-4 sm:grid-cols-2">
                  <label><span className="label">Estado</span>
                    <select disabled={!canEdit} className="input" value={form.status} onChange={(e) => setField('status', e.target.value)}>
                      {STATUSES.map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </label>
                  <label><span className="label">Prioridad</span>
                    <select disabled={!canEdit} className="input" value={form.priority} onChange={(e) => setField('priority', e.target.value)}>
                      {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
                    </select>
                  </label>
                  <label><span className="label">Categoría</span>
                    <select disabled={!canEdit} className="input" value={form.category_id} onChange={(e) => setField('category_id', e.target.value)}>
                      {options.categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </label>
                  <label><span className="label">Asignado a</span>
                    <select disabled={!canEdit} className="input" value={form.assigned_to} onChange={(e) => setField('assigned_to', e.target.value)}>
                      <option value="">Sin asignar</option>
                      {options.agents.map((a) => <option key={a.id} value={a.id}>{a.full_name}</option>)}
                    </select>
                  </label>
                </div>

                <label className="block"><span className="label">Solución aplicada <span className="normal-case tracking-normal text-slate-400">(obligatoria para resolver o cerrar)</span></span>
                  <textarea disabled={!canEdit} rows={4} className="input" value={form.solution} onChange={(e) => setField('solution', e.target.value)} />
                </label>

                <div className="flex flex-wrap gap-x-8 gap-y-3 rounded-xl bg-slate-50 p-4 text-sm">
                  <label className="flex items-center gap-2"><input type="checkbox" className="check" disabled={!canEdit} checked={form.fcr} onChange={(e) => setField('fcr', e.target.checked)} /> Resolución en 1er contacto</label>
                  <label className="flex items-center gap-2"><input type="checkbox" className="check" disabled={!canEdit} checked={form.documented} onChange={(e) => setField('documented', e.target.checked)} /> Documentado</label>
                  <span className="text-slate-600">Satisfacción: <strong className="text-slate-900">{ticket.csat ? `${ticket.csat} / 5` : 'sin evaluar'}</strong></span>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <label><span className="label">Etiquetas</span>
                    <input disabled={!canEdit} className="input" value={form.tags} onChange={(e) => setField('tags', e.target.value)} placeholder="hardware, urgente" />
                  </label>
                  <label><span className="label">Usuarios incluidos (watchers)</span>
                    <input disabled={!canEdit} className="input" value={form.watchers} onChange={(e) => setField('watchers', e.target.value)} placeholder="jefe@index.com.gt" />
                  </label>
                </div>

                {canEdit && (
                  <button className="btn-primary" onClick={save} disabled={busy}>
                    {busy ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} Guardar cambios
                  </button>
                )}
              </div>
            )}

            {tab === 2 && (
              <div className="space-y-3">
                {ticket.attachments.length === 0 && (
                  <div className="rounded-2xl border border-dashed border-slate-300 py-10 text-center text-sm text-slate-400">Este ticket no tiene adjuntos.</div>
                )}
                {ticket.attachments.map((a: any) => (
                  <div key={a.id} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600"><FileText size={18} /></span>
                    <div className="min-w-0 flex-1">
                      <a className="block truncate text-sm font-medium text-indigo-700 hover:underline" target="_blank" rel="noreferrer"
                        href={`${API}/api/tickets/attachments/${a.id}/download?token=${getToken()}`}>{a.original_name}</a>
                      <p className="text-xs text-slate-400">{(a.size_bytes / 1024 / 1024).toFixed(2)} MB · {fmtDate(a.created_at)}</p>
                    </div>
                    {canEdit && (
                      <button className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600" onClick={() => removeAttachment(a.id)} title="Eliminar">
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                ))}
                {canEdit && (
                  <label className={`flex cursor-pointer flex-col items-center gap-1 rounded-2xl border-2 border-dashed border-slate-300 py-8 text-center transition hover:border-indigo-400 hover:bg-indigo-50/40 ${ticket.attachments.length >= MAX_FILES ? 'pointer-events-none opacity-50' : ''}`}>
                    <Upload size={22} className="text-indigo-500" />
                    <span className="text-sm font-medium text-slate-700">Haz clic para subir archivos</span>
                    <span className="text-xs text-slate-400">Máximo 5 archivos por ticket · 10 MB cada uno</span>
                    <input type="file" multiple hidden disabled={busy} onChange={upload}
                      accept=".png,.jpg,.jpeg,.gif,.webp,.pdf,.txt,.log,.csv,.doc,.docx,.xls,.xlsx,.zip" />
                  </label>
                )}
              </div>
            )}

            {tab === 3 && (
              <ol className="relative space-y-4 border-l-2 border-slate-100 pl-6">
                {ticket.events.length === 0 && <p className="text-sm text-slate-400">Sin eventos registrados.</p>}
                {ticket.events.map((e: any) => (
                  <li key={e.id} className="relative">
                    <span className="absolute -left-[31px] top-1 h-3 w-3 rounded-full border-2 border-white bg-indigo-500 ring-2 ring-indigo-100" />
                    <p className="text-sm font-semibold capitalize text-slate-800">{String(e.action).replace('_', ' ')}</p>
                    <p className="text-xs text-slate-500">
                      {fmtFull(e.created_at)} · {e.actor_name || 'Sistema'}
                      {e.detail && Object.keys(e.detail).length > 0 && ` · ${Object.entries(e.detail).map(([k, v]) => `${k}: ${v}`).join(', ')}`}
                    </p>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </div>

        <aside className="space-y-4">
          <div className="card p-5">
            <p className="section-title mb-3">Solicitante</p>
            <div className="flex items-center gap-3">
              <Avatar name={ticket.requester_name} size={42} />
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-900">{ticket.requester_name}</p>
                <p className="truncate text-xs text-slate-500">{ticket.requester_email}</p>
              </div>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-4">
              <p className="text-xs text-slate-400">Asignado a</p>
              <p className="text-sm font-medium text-slate-800">{ticket.assigned_name || 'Sin asignar'}</p>
            </div>
          </div>

          <div className="card space-y-3 p-5">
            <p className="section-title">Acuerdos de servicio (SLA)</p>
            <SlaLine label="Primera respuesta" done={ticket.first_response_at} due={ticket.response_due_at} breached={ticket.sla_response_breached} />
            <SlaLine label="Resolución" done={ticket.resolved_at} due={ticket.resolution_due_at} breached={ticket.sla_resolution_breached} />
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="rounded-xl bg-indigo-50 p-3">
                <p className="text-[11px] text-indigo-500">Respuesta</p>
                <p className="text-lg font-semibold text-indigo-900">{ticket.response_minutes ?? '—'}<span className="ml-1 text-xs font-medium">min</span></p>
              </div>
              <div className="rounded-xl bg-violet-50 p-3">
                <p className="text-[11px] text-violet-500">Resolución</p>
                <p className="text-lg font-semibold text-violet-900">{ticket.resolution_hours ?? '—'}<span className="ml-1 text-xs font-medium">h</span></p>
              </div>
            </div>
          </div>

          <div className="card p-5">
            <p className="section-title mb-3">Etiquetas y watchers</p>
            <div className="flex flex-wrap gap-1.5">
              {ticket.tags.length === 0 && <span className="text-xs text-slate-400">Sin etiquetas</span>}
              {ticket.tags.map((t: string) => (
                <span key={t} className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">#{t}</span>
              ))}
            </div>
            <div className="mt-3 space-y-1.5">
              {ticket.watchers.map((w: any) => (
                <p key={w.id} className="truncate text-xs text-slate-500">👁 {w.email}</p>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </AppShell>
  );
}
