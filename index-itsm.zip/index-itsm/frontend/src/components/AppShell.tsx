'use client';
import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Headset, LayoutDashboard, LifeBuoy, LogOut, Menu, Ticket, X } from 'lucide-react';
import { logout, User } from '@/lib/auth';
import { Avatar } from '@/components/ui';

const ROLE_LABEL: Record<string, string> = {
  agent: 'Agente · Nivel 3',
  observer: 'Gerencia · BI',
  end_user: 'Colaborador',
};

type Props = {
  user: User;
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  wide?: boolean;
};

export default function AppShell({ user, title, subtitle, actions, children, wide }: Props) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const items = [
    { href: '/portal', label: 'Portal de soporte', icon: LifeBuoy, show: true },
    { href: '/tickets', label: 'Tickets', icon: Ticket, show: user.role !== 'end_user' },
    { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, show: user.role !== 'end_user' },
  ].filter((i) => i.show);

  const sidebar = (
    <div className="flex h-full flex-col bg-gradient-to-b from-[#0b1020] via-[#0f1530] to-[#141c45] text-slate-300">
      <div className="flex items-center gap-3 px-6 pb-6 pt-7">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-400 to-violet-600 text-white shadow-lg shadow-indigo-900/50">
          <Headset size={20} />
        </span>
        <div className="leading-tight">
          <p className="text-[15px] font-semibold tracking-tight text-white">Index IT</p>
          <p className="text-[11px] uppercase tracking-widest text-indigo-300/80">Service Desk</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3">
        <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">Menú</p>
        {items.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || (href !== '/portal' && pathname.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              onClick={() => setOpen(false)}
              className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                active ? 'bg-white/10 text-white ring-1 ring-white/10' : 'text-slate-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Icon size={18} className={active ? 'text-indigo-300' : 'text-slate-500 group-hover:text-indigo-300'} />
              {label}
              {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-indigo-400" />}
            </Link>
          );
        })}
      </nav>

      <div className="m-3 rounded-2xl border border-white/10 bg-white/5 p-3">
        <div className="flex items-center gap-3">
          <Avatar name={user.name} size={38} />
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-white">{user.name}</p>
            <p className="truncate text-[11px] text-slate-400">{ROLE_LABEL[user.role]}</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg bg-white/5 py-2 text-xs font-medium text-slate-300 transition hover:bg-white/10 hover:text-white"
        >
          <LogOut size={14} /> Cerrar sesión
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[268px] lg:block">{sidebar}</aside>

      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-[268px] shadow-2xl">{sidebar}</div>
        </div>
      )}

      <div className="lg:pl-[268px]">
        <div className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200/70 bg-white/80 px-4 py-3 backdrop-blur lg:hidden">
          <button onClick={() => setOpen(!open)} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100">
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
          <span className="text-sm font-semibold text-slate-800">Index IT · Service Desk</span>
          <Avatar name={user.name} size={30} />
        </div>

        <main className={`mx-auto animate-rise px-4 py-8 sm:px-8 ${wide ? 'max-w-[1400px]' : 'max-w-6xl'}`}>
          <header className="mb-7 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight text-slate-900 sm:text-[28px]">{title}</h1>
              {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
            </div>
            {actions}
          </header>
          {children}
        </main>
      </div>
    </div>
  );
}
