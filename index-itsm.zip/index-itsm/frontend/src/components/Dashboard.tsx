'use client';
import { useCallback, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { AreaChart, BarChart, DonutChart, Legend } from '@tremor/react';
import {
  Activity, AlertTriangle, CheckCircle2, CircleDot, Clock, FileCheck2, Hourglass, Inbox, Smile, Timer, Zap,
} from 'lucide-react';
import { API, api, getToken } from '@/lib/api';
import AppShell from '@/components/AppShell';
import { PriorityChip, StatusChip, fmtDate } from '@/components/ui';
import type { User } from '@/lib/auth';

const DONUT_COLORS = ['indigo', 'cyan', 'violet', 'fuchsia', 'amber', 'emerald', 'rose', 'sky', 'slate'];

function Kpi({ title, value, suffix, hint, icon: Icon, tone }: {
  title: string; value: number | string | null | undefined; suffix?: string; hint?: string; icon: any; tone: string;
}) {
  return (
    <div className="card p-5 transition hover:-translate-y-0.5 hover:shadow-lift">
      <div className="flex items-start justify-between">
        <p className="text-sm font-medium text-slate-500">{title}</p>
        <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${tone}`}><Icon size={18} /></span>
      </div>
      <p className="mt-3 text-[32px] font-semibold leading-none tracking-tight text-slate-900">
        {value ?? '—'}
        {value != null && suffix && <span className="ml-1 text-base font-medium text-slate-400">{suffix}</span>}
      </p>
      {hint && <p className="mt-2 text-xs text-slate-400">{hint}</p>}
    </div>
  );
}

function SlaMeter({ title, pct }: { title: string; pct: number | null | undefined }) {
  const v = pct ?? 0;
  const bar = pct == null ? 'bg-slate-300' : v >= 90 ? 'bg-emerald-500' : v >= 75 ? 'bg-amber-500' : 'bg-red-500';
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-slate-500">{title}</p>
        <span className="text-lg font-semibold text-slate-900">{pct == null ? '—' : `${pct}%`}</span>
      </div>
      <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-slate-100">
        <div className={`h-full rounded-full transition-all duration-700 ${bar}`} style={{ width: `${v}%` }} />
      </div>
      <p className="mt-2 text-xs text-slate-400">Meta corporativa: 90%</p>
    </div>
  );
}

export default function Dashboard({ user }: { user: User }) {
  const [days, setDays] = useState(30);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState('');
  const [live, setLive] = useState(false);

  const load = useCallback(async () => {
    try {
      setData(await api(`/api/dashboard/kpis?days=${days}`));
      setError('');
    } catch (e: any) {
      setError(e.message);
    }
  }, [days]);

  useEffect(() => {
    load();
    const timer = setInterval(load, 60000);
    return () => clearInterval(timer);
  }, [load]);

  useEffect(() => {
    const socket = io(API, { auth: { token: getToken() }, transports: ['websocket'] });
    socket.on('connect', () => setLive(true));
    socket.on('disconnect', () => setLive(false));
    socket.on('dashboard:refresh', load);
    return () => { socket.disconnect(); };
  }, [load]);

  const actions = (
    <div className="flex items-center gap-3">
      <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium ring-1 ring-inset ${live ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-slate-100 text-slate-500 ring-slate-200'}`}>
        <span className={`h-2 w-2 rounded-full ${live ? 'animate-pulse bg-emerald-500' : 'bg-slate-400'}`} />
        {live ? 'En vivo' : 'Sin conexión en vivo'}
      </span>
      <div className="inline-flex rounded-xl border border-slate-200 bg-white p-1 shadow-sm">
        {[7, 30, 90].map((d) => (
          <button
            key={d}
            onClick={() => setDays(d)}
            className={`rounded-lg px-3.5 py-1.5 text-sm font-medium transition ${days === d ? 'bg-indigo-600 text-white shadow' : 'text-slate-600 hover:bg-slate-50'}`}
          >
            {d} días
          </button>
        ))}
      </div>
    </div>
  );

  if (error) {
    return <AppShell user={user} title="Dashboard" wide><p className="text-red-600">{error}</p></AppShell>;
  }
  if (!data) {
    return <AppShell user={user} title="Dashboard" wide><p className="text-slate-500">Cargando indicadores…</p></AppShell>;
  }

  const { backlog, metrics, by_category, by_priority, by_day, oldest_open } = data;

  return (
    <AppShell
      user={user}
      wide
      title="Dashboard de Gerencia"
      subtitle={`Soporte IT · Index, S.A. · actualizado ${new Date(data.generated_at).toLocaleTimeString('es-GT')}`}
      actions={actions}
    >
      <div className="space-y-8">
        <section>
          <p className="section-title mb-3">Cola actual</p>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
            <Kpi title="Abiertos" value={backlog.abiertos} icon={Inbox} tone="bg-rose-50 text-rose-600" />
            <Kpi title="En progreso" value={backlog.en_progreso} icon={Activity} tone="bg-amber-50 text-amber-600" />
            <Kpi title="Resueltos" value={backlog.resueltos} icon={CheckCircle2} tone="bg-sky-50 text-sky-600" hint="Pendientes de cierre" />
            <Kpi title="Cerrados" value={backlog.cerrados} icon={CircleDot} tone="bg-emerald-50 text-emerald-600" />
            <Kpi title="SLA vencido" value={backlog.vencidos} icon={AlertTriangle} tone="bg-red-50 text-red-600" hint="Abiertos o en progreso" />
          </div>
        </section>

        <section>
          <p className="section-title mb-3">Desempeño · últimos {days} días · {metrics.total} tickets</p>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Kpi title="Tiempo de respuesta" value={metrics.avg_response_minutes} suffix="min" icon={Timer} tone="bg-indigo-50 text-indigo-600" hint="Promedio" />
            <Kpi title="Tiempo de resolución" value={metrics.avg_resolution_hours} suffix="h" icon={Hourglass} tone="bg-violet-50 text-violet-600" hint="Promedio" />
            <Kpi title="Resolución 1er contacto" value={metrics.fcr_pct} suffix="%" icon={Zap} tone="bg-emerald-50 text-emerald-600" />
            <Kpi title="Documentados" value={metrics.documented_pct} suffix="%" icon={FileCheck2} tone="bg-cyan-50 text-cyan-600" />
          </div>
          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            <Kpi title="Satisfacción del usuario" value={metrics.csat_avg} suffix="/ 5" icon={Smile} tone="bg-amber-50 text-amber-600" hint={`${metrics.csat_count} evaluaciones`} />
            <SlaMeter title="SLA de primera respuesta cumplido" pct={metrics.sla_response_pct} />
            <SlaMeter title="SLA de resolución cumplido" pct={metrics.sla_resolution_pct} />
          </div>
        </section>

        <section className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-slate-900">Creados vs. resueltos</h3>
              <p className="text-sm text-slate-500">Volumen diario de tickets</p>
            </div>
          </div>
          <AreaChart
            className="mt-4 h-72"
            data={by_day}
            index="day"
            categories={['Creados', 'Resueltos']}
            colors={['indigo', 'emerald']}
            yAxisWidth={32}
            allowDecimals={false}
            curveType="monotone"
            showGradient
          />
        </section>

        <section className="grid gap-4 lg:grid-cols-2">
          <div className="card p-6">
            <h3 className="text-base font-semibold text-slate-900">Tickets por categoría</h3>
            <p className="text-sm text-slate-500">Dónde se concentra la demanda</p>
            <DonutChart
              className="mt-6 h-52"
              data={by_category}
              category="value"
              index="name"
              colors={DONUT_COLORS as any}
              valueFormatter={(v: number) => `${v}`}
            />
            <Legend className="mt-5 justify-center" categories={by_category.map((c: any) => c.name)} colors={DONUT_COLORS as any} />
          </div>
          <div className="card p-6">
            <h3 className="text-base font-semibold text-slate-900">Tickets por prioridad</h3>
            <p className="text-sm text-slate-500">Distribución según urgencia</p>
            <BarChart
              className="mt-6 h-72"
              data={by_priority}
              index="priority"
              categories={['Tickets']}
              colors={['indigo']}
              yAxisWidth={32}
              allowDecimals={false}
              showLegend={false}
            />
          </div>
        </section>

        <section className="card overflow-hidden">
          <div className="flex items-center gap-2 border-b border-slate-100 px-6 py-4">
            <Clock size={18} className="text-slate-400" />
            <h3 className="text-base font-semibold text-slate-900">Pendientes más antiguos</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50/70 text-[11px] uppercase tracking-wider text-slate-500">
                <tr>
                  {['Ticket', 'Categoría', 'Prioridad', 'Estado', 'Creado', 'SLA'].map((h) => (
                    <th key={h} className="px-6 py-3 font-semibold">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {oldest_open.map((t: any) => (
                  <tr key={t.id} className="hover:bg-slate-50/60">
                    <td className="px-6 py-3.5 font-semibold text-indigo-700">{t.code}</td>
                    <td className="px-6 py-3.5 text-slate-600">{t.category}</td>
                    <td className="px-6 py-3.5"><PriorityChip priority={t.priority} /></td>
                    <td className="px-6 py-3.5"><StatusChip status={t.status} /></td>
                    <td className="px-6 py-3.5 text-slate-500">{fmtDate(t.created_at)}</td>
                    <td className="px-6 py-3.5">
                      <span className={`text-xs font-semibold ${t.sla_resolution_breached ? 'text-red-600' : 'text-emerald-600'}`}>
                        {t.sla_resolution_breached ? '● Vencido' : '● En tiempo'}
                      </span>
                    </td>
                  </tr>
                ))}
                {oldest_open.length === 0 && (
                  <tr><td colSpan={6} className="px-6 py-10 text-center text-slate-400">No hay tickets pendientes 🎉</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
