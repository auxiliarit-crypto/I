'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Paperclip, Search } from 'lucide-react';
import AppShell from '@/components/AppShell';
import { Avatar, PriorityChip, StatusChip, fmtDate } from '@/components/ui';
import { api } from '@/lib/api';
import { useRequireRole } from '@/lib/auth';

const FILTERS = ['', 'Abierto', 'En progreso', 'Resuelto', 'Cerrado'];

export default function TicketsPage() {
  const user = useRequireRole(['agent', 'observer']);
  const router = useRouter();
  const [tickets, setTickets] = useState<any[]>([]);
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const [q, setQ] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const params = new URLSearchParams();
    if (status) params.set('status', status);
    if (priority) params.set('priority', priority);
    if (q) params.set('q', q);
    const t = setTimeout(() => {
      api(`/api/tickets?${params}`)
        .then((r) => { setTickets(r); setError(''); })
        .catch((e) => setError(e.message))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [user, status, priority, q]);

  if (!user) return null;

  return (
    <AppShell user={user} wide title="Tickets" subtitle="Bandeja de soporte · todos los casos reportados">
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="inline-flex flex-wrap rounded-xl border border-slate-200 bg-white p-1 shadow-sm">
          {FILTERS.map((f) => (
            <button
              key={f || 'todos'}
              onClick={() => setStatus(f)}
              className={`rounded-lg px-3.5 py-1.5 text-sm font-medium transition ${status === f ? 'bg-indigo-600 text-white shadow' : 'text-slate-600 hover:bg-slate-50'}`}
            >
              {f || 'Todos'}
            </button>
          ))}
        </div>
        <select value={priority} onChange={(e) => setPriority(e.target.value)} className="input !w-auto">
          <option value="">Toda prioridad</option>
          <option>Alta</option><option>Media</option><option>Baja</option>
        </select>
        <div className="relative ml-auto w-full sm:w-80">
          <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por texto o correo…" className="input !pl-10" />
        </div>
      </div>

      {error && <p className="mb-4 text-red-600">{error}</p>}

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50/70 text-[11px] uppercase tracking-wider text-slate-500">
              <tr>
                {['Ticket', 'Asunto', 'Estado', 'Prioridad', 'Solicitante', 'Creado', 'Asignado', 'SLA'].map((h) => (
                  <th key={h} className="whitespace-nowrap px-5 py-3.5 font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {tickets.map((t) => (
                <tr key={t.id} onClick={() => router.push(`/tickets/${t.id}`)} className="cursor-pointer transition hover:bg-indigo-50/40">
                  <td className="whitespace-nowrap px-5 py-4">
                    <Link className="font-semibold text-indigo-700" href={`/tickets/${t.id}`}>{t.code}</Link>
                  </td>
                  <td className="max-w-xs px-5 py-4">
                    <p className="truncate font-medium text-slate-800">{t.category}</p>
                    <p className="flex items-center gap-1 truncate text-xs text-slate-400">
                      {t.attachments_count > 0 && <Paperclip size={11} />} {t.description}
                    </p>
                  </td>
                  <td className="px-5 py-4"><StatusChip status={t.status} /></td>
                  <td className="px-5 py-4"><PriorityChip priority={t.priority} /></td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-2">
                      <Avatar name={t.requester_name} size={26} />
                      <span className="max-w-[160px] truncate text-slate-600">{t.requester_email}</span>
                    </div>
                  </td>
                  <td className="whitespace-nowrap px-5 py-4 text-slate-500">{fmtDate(t.created_at)}</td>
                  <td className="whitespace-nowrap px-5 py-4 text-slate-600">{t.assigned_name || <span className="text-slate-300">—</span>}</td>
                  <td className="px-5 py-4">
                    {['Abierto', 'En progreso'].includes(t.status) && (
                      <span className={`text-xs font-semibold ${t.sla_resolution_breached ? 'text-red-600' : 'text-emerald-600'}`}>
                        ● {t.sla_resolution_breached ? 'Vencido' : 'En tiempo'}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
              {!loading && tickets.length === 0 && (
                <tr><td colSpan={8} className="px-5 py-14 text-center text-slate-400">No se encontraron tickets con esos filtros.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
