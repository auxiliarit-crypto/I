'use client';
import TicketWorkspace from '@/components/TicketWorkspace';
import { useRequireRole } from '@/lib/auth';

export default function TicketPage({ params }: { params: { id: string } }) {
  const user = useRequireRole(['agent', 'observer']);
  if (!user) return null;
  return <TicketWorkspace ticketId={Number(params.id)} user={user} />;
}
