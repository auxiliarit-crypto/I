'use client';
import Dashboard from '@/components/Dashboard';
import { useRequireRole } from '@/lib/auth';

export default function DashboardPage() {
  const user = useRequireRole(['agent', 'observer']);
  if (!user) return null;
  return <Dashboard user={user} />;
}
