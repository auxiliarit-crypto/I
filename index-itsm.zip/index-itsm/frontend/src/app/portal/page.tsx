'use client';
import { useCallback, useEffect, useState } from 'react';
import {
  Boxes, ChevronDown, ClipboardList, Database, HelpCircle, Layers, Lightbulb, Loader2, Mail, Monitor,
  Paperclip, Printer, Send, Star, Tag, Users, Wallet, Wifi, X,
} from 'lucide-react';
import AppShell from '@/components/AppShell';
import { StatusChip, PriorityChip, fmtDate } from '@/components/ui';
import { api } from '@/lib/api';
import { useRequireRole } from '@/lib/auth';

const ICONS: Record<string, any> = {
  'Equipo de computo': Monitor,
  Aspradco: Boxes,
  'Cuenta Corriente': Wallet,
  Ordenes: ClipboardList,
  SAP: Layers,
  Correo: Mail,
  Impresora: Printer,
  Internet: Wifi,
  Otro: HelpCircle,
};

function MyTicket({ t, onRate, onChanged }: { t: any; onRate: (id: number, n: number) => void; onChanged: () => void }) {
  const [open, setOpen] = useState(false);
  const [comments, setComments] = useState<any[]>([]);
  const [reply, setReply] = useState('');
  const [sending, setSending] = useState(false);

  const loadComments = useCallback(() => api(`/api/portal/tickets/${t.id}/comments`).then(setComments).catch(() => {}), [t.id]);
  useEffect(() => { if (open) loadComments(); }, [open, loadComments]);

  async function send() {
    if (!reply.trim()) return;
    setSending(true);
    try {
      await api(`/api/portal/tickets/${t.id}/comments`, { method: 'POST', body: JSON.stringify({ body: reply }) });
      setReply('');
      await loadComments();
      onChanged();
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 transition hover:shadow-soft">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-semibold text-slate-900">{t.code} · {t.category}</p>
          <p className="text-xs text-slate-400">{fmtDate(t.created_at)}</p>
        </div>
        <StatusChip status={t.status} />
      </div>
      <p className="mt-2 line-clamp-2 text-sm text-slate-600">{t.description}</p>

      {t.solution && (
        <div className="mt-3 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800 ring-1 ring-emerald-100">
          <span className="font-semibold">Solución:</span> {t.solution}
        </div>
      )}

      {t.is_owner && ['Resuelto', 'Cerrado'].includes(t.status) && (
        <div className="mt-3 flex items-center gap-1">
          <span className="mr-2 text-xs text-slate-500">{t.csat ? 'Tu calificación' : 'Califica la atención'}</span>
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} onClick={() => onRate(t.id, n)} title={`${n} de 5`}>
              <Star size={20} className={n <= (t.csat || 0) ? 'fill-amber-400 text-amber-400' : 'text-slate-300 hover:text-amber-300'} />
            </button>
          ))}
        </div>
      )}

      {t.is_owner && (
        <>
          <button onClick={() => setOpen(!open)} className="mt-3 flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800">
            Conversación con IT <ChevronDown size={14} className={`transition ${open ? 'rotate-180' : ''}`} />
          </button>
          {open && (
            <div className="mt-3 space-y-2">
              {comments.length === 0 && <p className="text-xs text-slate-400">Aún no hay mensajes.</p>}
              {comments.map((c) => (
                <div key={c.id} className={`rounded-xl p-3 text-sm ${c.author_role === 'end_user' ? 'ml-6 bg-slate-100' : 'mr-6 bg-indigo-50'}`}>
                  <p className="text-[11px] text-slate-500">{c.author_name} · {fmtDate(c.created_at)}</p>
                  <p className="whitespace-pre-wrap text-slate-800">{c.body}</p>
                </div>
              ))}
              <div className="flex gap-2">
                <input className="input" value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Escribe un mensaje…"
                  onKeyDown={(e) => e.key === 'Enter' && send()} />
                <button className="btn-primary !px-3" onClick={send} disabled={sending || !reply.trim()}>
                  {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default function Portal() {
  const user = useRequireRole(['end_user', 'agent', 'observer']);
  const [categories, setCategories] = useState<any[]>([]);
  const [mine, setMine] = useState<any[]>([]);
  const [categoryId, setCategoryId] = useState('');
  const [priority, setPriority] = useState('');
  const [description, setDescription] = useState('');
  const [watchers, setWatchers] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [deflect, setDeflect] = useState<any>(null);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const loadMine = useCallback(() => api('/api/portal/my-tickets').then(setMine).catch(() => {}), []);

  useEffect(() => {
    if (!user) return;
    api('/api/portal/catalog').then((c) => { setCategories(c); if (c[0]) setCategoryId(String(c[0].id)); });
    loadMine();
  }, [user, loadMine]);

  useEffect(() => {
    if (description.trim().length < 25) { setDeflect(null); return; }
    const t = setTimeout(async () => {
      try {
        setDeflect(await api('/api/portal/deflect', { method: 'POST', body: JSON.stringify({ category_id: categoryId, description }) }));
      } catch { /* la deflexión es opcional */ }
    }, 900);
    return () => clearTimeout(t);
  }, [description, categoryId]);

  function onFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const list = Array.from(e.target.files || []);
    if (list.length > 5) return setMsg({ type: 'err', text: 'Máximo 5 archivos' });
    const big = list.find((f) => f.size > 10 * 1024 * 1024);
    if (big) return setMsg({ type: 'err', text: `"${big.name}" supera los 10 MB` });
    setMsg(null);
    setFiles(list);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      const fd = new FormData();
      fd.append('category_id', categoryId);
      if (priority) fd.append('priority', priority);
      fd.append('description', description);
      fd.append('watchers', watchers);
      files.forEach((f) => fd.append('files', f));
      const t = await api('/api/portal/tickets', { method: 'POST', body: fd });
      setMsg({ type: 'ok', text: `Ticket ${t.code} creado. IT lo atenderá según su prioridad.` });
      setDescription(''); setWatchers(''); setFiles([]); setPriority(''); setDeflect(null);
      loadMine();
    } catch (err: any) {
      setMsg({ type: 'err', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function rate(id: number, score: number) {
    try { await api(`/api/portal/tickets/${id}/rating`, { method: 'POST', body: JSON.stringify({ score }) }); loadMine(); }
    catch (err: any) { setMsg({ type: 'err', text: err.message }); }
  }

  if (!user) return null;
  const first = user.name.split(' ')[0];

  return (
    <AppShell user={user} wide title={`Hola, ${first} 👋`} subtitle="¿Con qué podemos ayudarte hoy?">
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <form onSubmit={submit} className="card space-y-6 p-6 sm:p-7">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">Reportar un problema</h2>
            <p className="text-sm text-slate-500">Elige la categoría y cuéntanos qué sucede.</p>
          </div>

          <div>
            <span className="label">1 · Categoría</span>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
              {categories.map((c) => {
                const Icon = ICONS[c.name] || Tag;
                const active = String(c.id) === categoryId;
                return (
                  <button
                    type="button"
                    key={c.id}
                    onClick={() => setCategoryId(String(c.id))}
                    title={c.description}
                    className={`flex items-center gap-3 rounded-xl border p-3 text-left transition ${
                      active ? 'border-indigo-500 bg-indigo-50 ring-4 ring-indigo-500/10' : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${active ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                      <Icon size={17} />
                    </span>
                    <span className={`text-sm font-medium ${active ? 'text-indigo-900' : 'text-slate-700'}`}>{c.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <span className="label">2 · Urgencia</span>
            <div className="inline-flex rounded-xl bg-slate-100 p-1 text-sm font-medium">
              {[['', 'Automática'], ['Alta', 'Alta'], ['Media', 'Media'], ['Baja', 'Baja']].map(([v, l]) => (
                <button
                  type="button"
                  key={v || 'auto'}
                  onClick={() => setPriority(v)}
                  className={`rounded-lg px-4 py-1.5 transition ${priority === v ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>

          <label className="block">
            <span className="label">3 · Descripción del problema</span>
            <textarea required rows={5} className="input" value={description} onChange={(e) => setDescription(e.target.value)}
              placeholder="Ej.: Desde esta mañana no puedo imprimir desde mi computadora…" />
          </label>

          {deflect && (deflect.ai || deflect.articles.length > 0) && (
            <div className="rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50 to-violet-50 p-4">
              <p className="flex items-center gap-2 text-sm font-semibold text-indigo-900">
                <Lightbulb size={16} /> Quizás esto resuelva tu problema sin esperar a IT
              </p>
              {deflect.ai && <p className="mt-2 whitespace-pre-wrap text-sm text-indigo-950/80">{deflect.ai}</p>}
              {deflect.articles.map((a: any) => (
                <details key={a.id} className="group mt-2 rounded-xl bg-white/70 p-3 text-sm">
                  <summary className="cursor-pointer font-medium text-slate-800">{a.title}</summary>
                  <p className="mt-2 text-slate-600">{a.body}</p>
                </details>
              ))}
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <span className="label">Capturas o archivos</span>
              <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-slate-300 px-3.5 py-2.5 text-sm text-slate-500 transition hover:border-indigo-400 hover:bg-indigo-50/40">
                <Paperclip size={16} /> {files.length ? `${files.length} archivo(s)` : 'Adjuntar (máx. 5 · 10 MB)'}
                <input type="file" multiple hidden onChange={onFiles}
                  accept=".png,.jpg,.jpeg,.gif,.webp,.pdf,.txt,.log,.csv,.doc,.docx,.xls,.xlsx,.zip" />
              </label>
              {files.length > 0 && (
                <button type="button" onClick={() => setFiles([])} className="mt-1 flex items-center gap-1 text-xs text-slate-400 hover:text-red-600"><X size={12} /> Quitar archivos</button>
              )}
            </div>
            <label>
              <span className="label"><Users size={11} className="mr-1 inline" />Incluir a otros (correos)</span>
              <input className="input" value={watchers} onChange={(e) => setWatchers(e.target.value)} placeholder="jefe@index.com.gt, …" />
            </label>
          </div>

          {msg && (
            <p className={`rounded-xl px-4 py-3 text-sm font-medium ${msg.type === 'ok' ? 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200' : 'bg-red-50 text-red-700 ring-1 ring-red-200'}`}>{msg.text}</p>
          )}

          <button type="submit" disabled={busy} className="btn-primary w-full !py-3.5 sm:w-auto">
            {busy ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />} Crear ticket
          </button>
        </form>

        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-900">Mis tickets</h2>
            <span className="rounded-full bg-slate-200/70 px-2.5 py-0.5 text-xs font-semibold text-slate-600">{mine.length}</span>
          </div>
          <div className="space-y-3">
            {mine.length === 0 && (
              <div className="card py-14 text-center text-sm text-slate-400">Aún no tienes tickets. ¡Qué bien! 🎉</div>
            )}
            {mine.map((t) => <MyTicket key={t.id} t={t} onRate={rate} onChanged={loadMine} />)}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
