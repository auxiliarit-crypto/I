'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Activity, ArrowRight, Headset, Loader2, Mail, ShieldCheck, Sparkles, Zap } from 'lucide-react';
import { api } from '@/lib/api';

const DEMOS = [
  { email: 'empleado@index.com.gt', label: 'Colaborador', hint: 'Portal de soporte' },
  { email: 'alex.menchu@index.com.gt', label: 'Alex Menchú', hint: 'Jefe de IT · N3' },
  { email: 'auxiliar.it@index.com.gt', label: 'Auxiliar de IT', hint: 'Agente · N3' },
  { email: 'jose.cuevas@index.com.gt', label: 'José R. Cuevas', hint: 'Gerencia · BI' },
];

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e?: React.FormEvent, forced?: string) {
    e?.preventDefault();
    setLoading(true);
    setError('');
    try {
      const { token, user } = await api('/api/auth/sso/dev', {
        method: 'POST',
        body: JSON.stringify({ email: forced ?? email }),
      });
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
      router.push(user.role === 'observer' ? '/dashboard' : user.role === 'agent' ? '/tickets' : '/portal');
    } catch (err: any) {
      setError(err.message === 'Failed to fetch' ? 'No se pudo conectar con el servidor (¿backend encendido?)' : err.message);
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen lg:grid-cols-[1.1fr_1fr]">
      <section className="relative hidden overflow-hidden bg-gradient-to-br from-[#0b1020] via-[#17205a] to-[#4338ca] p-14 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-violet-500/30 blur-3xl" />
        <div className="absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-indigo-400/20 blur-3xl" />
        <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '26px 26px' }} />

        <div className="relative flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/15 ring-1 ring-white/25 backdrop-blur"><Headset size={22} /></span>
          <div className="leading-tight">
            <p className="text-lg font-semibold tracking-tight">Index IT</p>
            <p className="text-[11px] uppercase tracking-[0.2em] text-indigo-200">Service Desk</p>
          </div>
        </div>

        <div className="relative max-w-lg">
          <h1 className="text-[44px] font-semibold leading-[1.1] tracking-tight">Soporte IT claro, rápido y medible.</h1>
          <p className="mt-5 text-lg text-indigo-100/80">Reporta un problema, sigue su avance y obtén respuesta dentro de los tiempos acordados.</p>
          <ul className="mt-10 space-y-5">
            {[
              { icon: Sparkles, t: 'Respuestas inmediatas', d: 'Sugerencias con IA antes de crear el ticket.' },
              { icon: Zap, t: 'Atención con SLA', d: 'Cada caso tiene tiempos de respuesta y resolución.' },
              { icon: Activity, t: 'Indicadores en vivo', d: 'Gerencia ve el desempeño en tiempo real.' },
            ].map(({ icon: Icon, t, d }) => (
              <li key={t} className="flex gap-4">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/15"><Icon size={18} /></span>
                <div><p className="font-semibold">{t}</p><p className="text-sm text-indigo-100/70">{d}</p></div>
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-xs text-indigo-200/60">© {new Date().getFullYear()} Index, S.A. · Departamento de Tecnología</p>
      </section>

      <section className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md animate-rise">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white"><Headset size={20} /></span>
            <p className="text-lg font-semibold text-slate-900">Index IT</p>
          </div>

          <h2 className="text-3xl font-semibold tracking-tight text-slate-900">Bienvenido</h2>
          <p className="mt-2 text-slate-500">Ingresa con tu correo corporativo.</p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <div className="relative">
              <Mail size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="usuario@index.com.gt"
                className="input !py-3.5 !pl-11"
              />
            </div>
            {error && <p className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 ring-1 ring-red-200">{error}</p>}
            <button type="submit" disabled={loading} className="btn-primary w-full !py-3.5">
              {loading ? <Loader2 size={18} className="animate-spin" /> : <ShieldCheck size={18} />}
              Ingresar con SSO
            </button>
          </form>

          <div className="mt-10">
            <p className="section-title mb-3">Cuentas de demostración</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {DEMOS.map((d) => (
                <button
                  key={d.email}
                  onClick={() => { setEmail(d.email); submit(undefined, d.email); }}
                  className="group flex items-center justify-between rounded-xl border border-slate-200 bg-white p-3 text-left transition hover:border-indigo-300 hover:shadow-soft"
                >
                  <span>
                    <span className="block text-sm font-semibold text-slate-800">{d.label}</span>
                    <span className="block text-xs text-slate-400">{d.hint}</span>
                  </span>
                  <ArrowRight size={16} className="text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-indigo-500" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
