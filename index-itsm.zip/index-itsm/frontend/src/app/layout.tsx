import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Index IT · Service Desk',
  description: 'Sistema de tickets de soporte IT de Index, S.A.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body className="min-h-screen">{children}</body>
    </html>
  );
}
