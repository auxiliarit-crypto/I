'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export type Role = 'agent' | 'observer' | 'end_user';
export type User = { id: string; email: string; name: string; role: Role };

export function getUser(): User | null {
  if (typeof window === 'undefined') return null;
  try {
    return JSON.parse(localStorage.getItem('user') || 'null');
  } catch {
    return null;
  }
}

export function logout() {
  localStorage.clear();
  window.location.href = '/';
}

export function useRequireRole(roles: Role[]): User | null {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    const u = getUser();
    if (!u || !localStorage.getItem('token') || !roles.includes(u.role)) {
      router.replace('/');
      return;
    }
    setUser(u);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return user;
}
