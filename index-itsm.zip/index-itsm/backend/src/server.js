import 'dotenv/config';
import http from 'node:http';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { pool } from './config/db.js';
import { redis } from './config/redis.js';
import authRoutes from './routes/auth.js';
import portalRoutes from './routes/portal.js';
import ticketRoutes from './routes/tickets.js';
import dashboardRoutes from './routes/dashboard.js';
import { initSockets, clearPresence } from './sockets/collision.js';
import { startAutomation } from './jobs/automation.js';

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', async (req, res) => {
  await pool.query('SELECT 1');
  res.json({ ok: true, redis: redis.status });
});

app.use('/api/auth', authRoutes);
app.use('/api/portal', portalRoutes);
app.use('/api/tickets', ticketRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: `Adjuntos: ${err.message} (máximo 5 archivos de 10 MB)` });
  }
  if (err.status) return res.status(err.status).json({ error: err.message });
  if (['22P02', '23502', '23503', '23505', '23514', 'P0001'].includes(err.code)) {
    return res.status(400).json({ error: err.message });
  }
  console.error(err);
  res.status(500).json({ error: 'Error interno del servidor' });
});

await pool.query('SELECT 1');
await clearPresence();

const server = http.createServer(app);
const io = initSockets(server);
app.set('io', io);
startAutomation(io);

const port = Number(process.env.PORT) || 4000;
server.listen(port, () => console.log(`API Index ITSM lista en http://localhost:${port}`));
