import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';
import { redis } from '../config/redis.js';

const key = (ticketId) => `presence:ticket:${ticketId}`;

export async function clearPresence() {
  const keys = await redis.keys('presence:ticket:*');
  if (keys.length) await redis.del(...keys);
}

async function getViewers(ticketId) {
  const raw = await redis.hvals(key(ticketId));
  const byUser = new Map();
  for (const item of raw) {
    const v = JSON.parse(item);
    const prev = byUser.get(v.userId);
    byUser.set(v.userId, prev ? { ...prev, typing: prev.typing || v.typing } : v);
  }
  return [...byUser.values()];
}

export function initSockets(httpServer) {
  const io = new Server(httpServer, {
    cors: { origin: process.env.FRONTEND_URL, credentials: true },
  });

  io.use((socket, next) => {
    try {
      const user = jwt.verify(socket.handshake.auth?.token, process.env.JWT_SECRET);
      if (!['agent', 'observer'].includes(user.role)) return next(new Error('forbidden'));
      socket.user = user;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    const viewing = new Set();
    socket.join('staff');

    const broadcast = async (ticketId) => {
      io.to(`ticket:${ticketId}`).emit('presence:update', {
        ticketId,
        viewers: await getViewers(ticketId),
      });
    };

    socket.on('ticket:view', async ({ ticketId } = {}) => {
      const id = Number(ticketId);
      if (!Number.isInteger(id)) return;
      socket.join(`ticket:${id}`);
      viewing.add(id);
      if (socket.user.role === 'agent') {
        await redis.hset(key(id), socket.id, JSON.stringify({
          userId: socket.user.id,
          name: socket.user.name,
          since: new Date().toISOString(),
          typing: false,
        }));
        await redis.expire(key(id), 3600);
      }
      await broadcast(id);
    });

    socket.on('ticket:typing', async ({ ticketId, typing } = {}) => {
      const id = Number(ticketId);
      if (!viewing.has(id) || socket.user.role !== 'agent') return;
      const current = await redis.hget(key(id), socket.id);
      if (!current) return;
      await redis.hset(key(id), socket.id, JSON.stringify({ ...JSON.parse(current), typing: Boolean(typing) }));
      await broadcast(id);
    });

    socket.on('ticket:leave', async ({ ticketId } = {}) => {
      const id = Number(ticketId);
      if (!viewing.has(id)) return;
      viewing.delete(id);
      socket.leave(`ticket:${id}`);
      await redis.hdel(key(id), socket.id);
      await broadcast(id);
    });

    socket.on('disconnecting', async () => {
      for (const id of viewing) {
        await redis.hdel(key(id), socket.id);
        await broadcast(id);
      }
    });
  });

  return io;
}
