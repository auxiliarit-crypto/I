import 'dotenv/config';
import Redis from 'ioredis';

export const redis = new Redis(process.env.REDIS_URL, { maxRetriesPerRequest: 3 });

redis.on('error', (err) => console.error('Error de Redis:', err.message));
