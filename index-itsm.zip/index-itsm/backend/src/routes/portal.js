import { Router } from 'express';
import { pool } from '../config/db.js';
import { auth } from '../middleware/auth.js';
import { upload, saveAttachments, removeFiles } from '../lib/uploads.js';
import { parseEmails, upsertUserByEmail } from '../lib/users.js';

const router = Router();
router.use(auth);

router.get('/catalog', async (req, res) => {
  const { rows } = await pool.query(
    `SELECT id, name, description, default_priority
     FROM categories WHERE active ORDER BY sort_order, name`
  );
  res.json(rows);
});

async function aiSuggestion(description, categoryName, articles) {
  if (!process.env.ANTHROPIC_API_KEY) return null;
  try {
    const context = articles.map((a) => `# ${a.title}\n${a.body}`).join('\n\n') || '(sin artículos relacionados)';
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
        max_tokens: 500,
        system:
          'Eres el asistente de soporte IT de Index, S.A. Responde en español, en máximo 6 líneas, con pasos concretos que un empleado no técnico pueda hacer solo. Usa únicamente la base de conocimiento dada cuando sea relevante. Si no hay una solución segura, di que conviene crear el ticket.',
        messages: [
          {
            role: 'user',
            content: `Categoría: ${categoryName}\nProblema: ${description}\n\nBase de conocimiento:\n${context}`,
          },
        ],
      }),
    });
    if (!response.ok) return null;
    const json = await response.json();
    return (json.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n') || null;
  } catch {
    return null;
  }
}

router.post('/deflect', async (req, res) => {
  const description = String(req.body.description || '');
  const words = [...new Set((description.toLowerCase().match(/[a-záéíóúñü0-9]{4,}/g) || []))].slice(0, 12);

  let articles = [];
  if (words.length) {
    const tsq = words.join(' | ');
    const { rows } = await pool.query(
      `SELECT id, title, body
       FROM kb_articles
       WHERE active AND to_tsvector('spanish', title || ' ' || body) @@ to_tsquery('spanish', $1)
       ORDER BY ts_rank(to_tsvector('spanish', title || ' ' || body), to_tsquery('spanish', $1)) DESC
       LIMIT 3`,
      [tsq]
    );
    articles = rows;
  }

  let categoryName = 'Otro';
  if (req.body.category_id) {
    const c = await pool.query('SELECT name FROM categories WHERE id = $1', [req.body.category_id]);
    if (c.rows[0]) categoryName = c.rows[0].name;
  }

  const ai = description.trim().length >= 25 ? await aiSuggestion(description, categoryName, articles) : null;
  res.json({ articles, ai });
});

router.post('/tickets', upload.array('files', 5), async (req, res) => {
  const files = req.files || [];
  const client = await pool.connect();
  try {
    const description = String(req.body.description || '').trim();
    if (description.length < 10) {
      removeFiles(files);
      return res.status(400).json({ error: 'Describa el problema (mínimo 10 caracteres)' });
    }

    await client.query('BEGIN');
    const cat = await client.query(
      'SELECT id, default_priority FROM categories WHERE id = $1 AND active',
      [req.body.category_id]
    );
    if (!cat.rows[0]) {
      await client.query('ROLLBACK');
      removeFiles(files);
      return res.status(400).json({ error: 'Categoría inválida' });
    }
    const priority = ['Alta', 'Media', 'Baja'].includes(req.body.priority)
      ? req.body.priority
      : cat.rows[0].default_priority;

    const t = await client.query(
      `INSERT INTO tickets (category_id, priority, requester_id, requester_email, description)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, 'IDX-' || lpad(id::text, 6, '0') AS code`,
      [cat.rows[0].id, priority, req.user.id, req.user.email, description]
    );
    const ticket = t.rows[0];

    await saveAttachments(client, ticket.id, req.user.id, files);

    for (const email of parseEmails(req.body.watchers)) {
      const uid = await upsertUserByEmail(client, email);
      await client.query(
        'INSERT INTO ticket_watchers (ticket_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [ticket.id, uid]
      );
    }
    await client.query(
      `INSERT INTO ticket_events (ticket_id, actor_id, action, detail) VALUES ($1, $2, 'creado', $3)`,
      [ticket.id, req.user.id, JSON.stringify({ priority })]
    );
    await client.query('COMMIT');

    const io = req.app.get('io');
    io.to('staff').emit('dashboard:refresh');
    io.to('staff').emit('ticket:new', { ticketId: ticket.id, code: ticket.code });
    res.status(201).json(ticket);
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    removeFiles(files);
    throw err;
  } finally {
    client.release();
  }
});

router.get('/my-tickets', async (req, res) => {
  const { rows } = await pool.query(
    `SELECT t.id, 'IDX-' || lpad(t.id::text, 6, '0') AS code, t.status, t.priority,
            c.name AS category, t.description, t.solution, t.created_at, t.closed_at, t.csat,
            (t.requester_id = $1) AS is_owner
     FROM tickets t JOIN categories c ON c.id = t.category_id
     WHERE t.requester_id = $1
        OR EXISTS (SELECT 1 FROM ticket_watchers w WHERE w.ticket_id = t.id AND w.user_id = $1)
     ORDER BY t.created_at DESC
     LIMIT 100`,
    [req.user.id]
  );
  res.json(rows);
});

router.get('/tickets/:id/comments', async (req, res) => {
  const { rows } = await pool.query(
    `SELECT cm.id, cm.body, cm.created_at, u.full_name AS author_name, u.role AS author_role
     FROM ticket_comments cm
     JOIN users u ON u.id = cm.author_id
     JOIN tickets t ON t.id = cm.ticket_id
     WHERE cm.ticket_id = $1 AND NOT cm.is_internal AND t.requester_id = $2
     ORDER BY cm.created_at`,
    [req.params.id, req.user.id]
  );
  res.json(rows);
});

router.post('/tickets/:id/comments', async (req, res) => {
  const body = String(req.body.body || '').trim();
  if (!body) return res.status(400).json({ error: 'Escriba un mensaje' });
  const own = await pool.query('SELECT 1 FROM tickets WHERE id = $1 AND requester_id = $2', [req.params.id, req.user.id]);
  if (!own.rowCount) return res.status(404).json({ error: 'Ticket no encontrado' });
  await pool.query(
    'INSERT INTO ticket_comments (ticket_id, author_id, body, is_internal) VALUES ($1, $2, $3, false)',
    [req.params.id, req.user.id, body]
  );
  req.app.get('io').to(`ticket:${req.params.id}`).emit('ticket:updated', { ticketId: Number(req.params.id) });
  res.status(201).json({ ok: true });
});

router.post('/tickets/:id/rating', async (req, res) => {
  const score = Number(req.body.score);
  if (!Number.isInteger(score) || score < 1 || score > 5) {
    return res.status(400).json({ error: 'La calificación debe ser de 1 a 5' });
  }
  const { rowCount } = await pool.query(
    `UPDATE tickets SET csat = $1
     WHERE id = $2 AND requester_id = $3 AND status IN ('Resuelto', 'Cerrado')`,
    [score, req.params.id, req.user.id]
  );
  if (!rowCount) return res.status(400).json({ error: 'Solo puede calificar sus tickets resueltos o cerrados' });
  req.app.get('io').to('staff').emit('dashboard:refresh');
  res.json({ ok: true });
});

export default router;
