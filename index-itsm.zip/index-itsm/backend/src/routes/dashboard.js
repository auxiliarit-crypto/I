import { Router } from 'express';
import { pool } from '../config/db.js';
import { auth, requireRole } from '../middleware/auth.js';

const router = Router();

router.get('/kpis', auth, requireRole('agent', 'observer'), async (req, res) => {
  const days = Math.min(Math.max(parseInt(req.query.days, 10) || 30, 1), 365);
  const windowSql = `t.created_at >= (current_date - ($1::int - 1))`;

  const [backlog, metrics, byCategory, byPriority, byDay, oldest] = await Promise.all([
    pool.query(`
      SELECT count(*) FILTER (WHERE status = 'Abierto')::int      AS abiertos,
             count(*) FILTER (WHERE status = 'En progreso')::int  AS en_progreso,
             count(*) FILTER (WHERE status = 'Resuelto')::int     AS resueltos,
             count(*) FILTER (WHERE status = 'Cerrado')::int      AS cerrados,
             count(*) FILTER (WHERE status IN ('Abierto','En progreso') AND sla_resolution_breached)::int AS vencidos
      FROM tickets`),

    pool.query(`
      SELECT count(*)::int AS total,
             round(avg(t.response_minutes)::numeric, 1)::float   AS avg_response_minutes,
             round(avg(t.resolution_hours)::numeric, 2)::float   AS avg_resolution_hours,
             round(100.0 * count(*) FILTER (WHERE t.fcr AND t.status IN ('Resuelto','Cerrado'))
                   / NULLIF(count(*) FILTER (WHERE t.status IN ('Resuelto','Cerrado')), 0), 1)::float AS fcr_pct,
             round(100.0 * count(*) FILTER (WHERE t.documented AND t.status IN ('Resuelto','Cerrado'))
                   / NULLIF(count(*) FILTER (WHERE t.status IN ('Resuelto','Cerrado')), 0), 1)::float AS documented_pct,
             round(avg(t.csat)::numeric, 2)::float AS csat_avg,
             count(t.csat)::int AS csat_count,
             round(100.0 * count(*) FILTER (WHERE t.first_response_at IS NOT NULL AND NOT t.sla_response_breached)
                   / NULLIF(count(*) FILTER (WHERE t.first_response_at IS NOT NULL OR t.sla_response_breached), 0), 1)::float AS sla_response_pct,
             round(100.0 * count(*) FILTER (WHERE t.resolved_at IS NOT NULL AND NOT t.sla_resolution_breached)
                   / NULLIF(count(*) FILTER (WHERE t.resolved_at IS NOT NULL OR t.sla_resolution_breached), 0), 1)::float AS sla_resolution_pct
      FROM tickets t WHERE ${windowSql}`, [days]),

    pool.query(`
      SELECT c.name, count(*)::int AS value
      FROM tickets t JOIN categories c ON c.id = t.category_id
      WHERE ${windowSql} GROUP BY c.name ORDER BY value DESC`, [days]),

    pool.query(`
      SELECT t.priority::text AS priority, count(*)::int AS "Tickets"
      FROM tickets t WHERE ${windowSql} GROUP BY t.priority ORDER BY t.priority`, [days]),

    pool.query(`
      SELECT to_char(d::date, 'DD/MM') AS day,
             (SELECT count(*) FROM tickets t WHERE t.created_at::date  = d::date)::int AS "Creados",
             (SELECT count(*) FROM tickets t WHERE t.resolved_at::date = d::date)::int AS "Resueltos"
      FROM generate_series((current_date - ($1::int - 1))::timestamp, current_date::timestamp, interval '1 day') d
      ORDER BY d`, [days]),

    pool.query(`
      SELECT t.id, 'IDX-' || lpad(t.id::text, 6, '0') AS code, t.status, t.priority,
             c.name AS category, t.created_at, t.sla_resolution_breached
      FROM tickets t JOIN categories c ON c.id = t.category_id
      WHERE t.status IN ('Abierto','En progreso')
      ORDER BY t.created_at ASC LIMIT 5`),
  ]);

  res.json({
    days,
    generated_at: new Date().toISOString(),
    backlog: backlog.rows[0],
    metrics: metrics.rows[0],
    by_category: byCategory.rows,
    by_priority: byPriority.rows,
    by_day: byDay.rows,
    oldest_open: oldest.rows,
  });
});

export default router;
