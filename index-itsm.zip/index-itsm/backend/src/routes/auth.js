import { Router } from 'express';
import { pool } from '../config/db.js';
import { auth, signToken } from '../middleware/auth.js';

const router = Router();

// SSO simulado (desarrollo). En producción: validar el id_token OIDC de Google/Microsoft
// y, con el correo verificado, ejecutar exactamente esta misma lógica de búsqueda + signToken.
router.post('/sso/dev', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const domain = (process.env.ALLOWED_DOMAIN || '').toLowerCase();

  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || !email.endsWith(`@${domain}`)) {
    return res.status(403).json({ error: `Solo se permiten correos @${domain}` });
  }

  let { rows } = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
  if (!rows[0]) {
    ({ rows } = await pool.query(
      'INSERT INTO users (email, full_name) VALUES ($1, $2) RETURNING *',
      [email, email.split('@')[0]]
    ));
  }
  const user = rows[0];
  if (!user.is_active) return res.status(403).json({ error: 'Usuario desactivado' });

  res.json({
    token: signToken(user),
    user: { id: user.id, email: user.email, name: user.full_name, role: user.role },
  });
});

router.get('/me', auth, (req, res) => res.json({ user: req.user }));

export default router;
