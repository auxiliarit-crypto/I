import { Router } from 'express';
import path from 'node:path';
import { pool } from '../config/db.js';
import { auth, requireRole } from '../middleware/auth.js';
import { upload, saveAttachments, removeFiles, uploadDir } from '../lib/uploads.js';
import { parseEmails, upsertUserByEmail } from '../lib/users.js';

const router = Router();
router.use(auth);

const staff = requireRole('agent', 'observer'); // lectura global
const agent = requireRole('agent');             // CRUD completo

const TICKET_SELECT = `
  SELECT t.id,
         'IDX-' || lpad(t.id::text, 6, '0') AS code,
         t.status, t.priority, t.category_id, c.name AS category,
         t.requester_id, t.requester_email, u.full_name AS requester_name,
         t.assigned_to, a.full_name AS assigned_name,
         t.description, t.solution,
         t.created_at, t.first_response_at, t.resolved_at, t.closed_at,
         t.response_due_at, t.resolution_due_at,
         t.sla_response_breached, t.sla_resolution_breached,
         t.fcr, t.documented, t.csat,
         t.response_minutes, t.resolution_hours::float AS resolution_hours,
         COALESCE((SELECT array_agg(g.name ORDER BY g.name)
                   FROM ticket_tags tt JOIN tags g ON g.id = tt.tag_id
                   WHERE tt.ticket_id = t.id), '{}') AS tags,
         (SELECT count(*)::int FROM attachments at WHERE at.ticket_id = t.id) AS attachments_count
  FROM tickets t
  JOIN categories c ON c.id = t.category_id
  JOIN users u ON u.id = t.requester_id
  LEFT JOIN users a ON a.id = t.assigned_to`;

async function getTicketDetail(id) {
  const t = await pool.query(`${TICKET_SELECT} WHERE t.id = $1`, [id]);
  if (!t.rows[0]) return null;
  const [comments, attachments, watchers, events] = await Promise.all([
    pool.query(
      `SELECT cm.id, cm.body, cm.is_internal, cm.created_at,
              u.full_name AS author_name, u.role AS author_role
       FROM ticket_comments cm JOIN users u ON u.id = cm.author_id
       WHERE cm.ticket_id = $1 ORDER BY cm.created_at`, [id]),
    pool.query(
      `SELECT id, original_name, mime_type, size_bytes, created_at
       FROM attachments WHERE ticket_id = $1 ORDER BY id`, [id]),
    pool.query(
      `SELECT u.id, u.email, u.full_name
       FROM ticket_watchers w JOIN users u ON u.id = w.user_id
       WHERE w.ticket_id = $1 ORDER BY u.email`, [id]),
    pool.query(
      `SELECT e.id, e.action, e.detail, e.created_at, u.full_name AS actor_name
       FROM ticket_events e LEFT JOIN users u ON u.id = e.actor_id
       WHERE e.ticket_id = $1 ORDER BY e.created_at DESC LIMIT 30`, [id]),
  ]);
  return {
    ...t.rows[0],
    comments: comments.rows,
    attachments: attachments.rows,
    watchers: watchers.rows,
    events: events.rows,
  };
}

function notify(req, id) {
  const io = req.app.get('io');
  io.to(`ticket:${id}`).emit('ticket:updated', { ticketId: id });
  io.to('staff').emit('dashboard:refresh');
}

router.get('/attachments/:id/download', async (req, res) => {
  const { rows } = await pool.query(
    `SELECT a.original_name, a.stored_name, t.requester_id
     FROM attachments a JOIN tickets t ON t.id = a.ticket_id WHERE a.id = $1`,
    [req.params.id]
  );
  const file = rows[0];
  if (!file) return res.status(404).json({ error: 'Adjunto no encontrado' });
  if (req.user.role === 'end_user' && file.requester_id !== req.user.id) {
    return res.status(403).json({ error: 'Permiso denegado' });
  }
  res.download(path.resolve(uploadDir, file.stored_name), file.original_name);
});

router.delete('/attachments/:id', agent, async (req, res) => {
  const { rows } = await pool.query(
    'DELETE FROM attachments WHERE id = $1 RETURNING ticket_id, stored_name',
    [req.params.id]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Adjunto no encontrado' });
  removeFiles([rows[0].stored_name]);
  notify(req, rows[0].ticket_id);
  res.json({ ok: true });
});

router.get('/meta', staff, async (req, res) => {
  const [categories, agents] = await Promise.all([
    pool.query('SELECT id, name FROM categories ORDER BY sort_order, name'),
    pool.query(`SELECT id, full_name FROM users WHERE role = 'agent' AND is_active ORDER BY full_name`),
  ]);
  res.json({ categories: categories.rows, agents: agents.rows });
});

router.get('/', staff, async (req, res) => {
  const where = [];
  const vals = [];
  const add = (sql, value) => {
    vals.push(value);
    where.push(sql.replaceAll('?', `$${vals.length}`));
  };
  if (req.query.status) add('t.status = ?', req.query.status);
  if (req.query.priority) add('t.priority = ?', req.query.priority);
  if (req.query.category_id) add('t.category_id = ?', req.query.category_id);
  if (req.query.assigned_to) add('t.assigned_to = ?', req.query.assigned_to);
  if (req.query.q) add('(t.description ILIKE ? OR t.requester_email ILIKE ?)', `%${req.query.q}%`);

  const { rows } = await pool.query(
    `${TICKET_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
     ORDER BY t.created_at DESC LIMIT 500`,
    vals
  );
  res.json(rows);
});

router.get('/:id', staff, async (req, res) => {
  const detail = await getTicketDetail(Number(req.params.id));
  if (!detail) return res.status(404).json({ error: 'Ticket no encontrado' });
  res.json(detail);
});

router.patch('/:id', agent, async (req, res) => {
  const id = Number(req.params.id);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const current = await client.query(
      'SELECT status, priority, solution FROM tickets WHERE id = $1 FOR UPDATE', [id]
    );
    if (!current.rows[0]) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Ticket no encontrado' });
    }
    const before = current.rows[0];

    const nextStatus = req.body.status ?? before.status;
    const nextSolution = 'solution' in req.body ? req.body.solution : before.solution;
    if (['Resuelto', 'Cerrado'].includes(nextStatus) && !String(nextSolution || '').trim()) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Debe registrar la Solución Aplicada para resolver o cerrar el ticket' });
    }

    const allowed = ['status', 'priority', 'category_id', 'assigned_to', 'solution', 'fcr', 'documented'];
    const sets = [];
    const vals = [];
    for (const field of allowed) {
      if (field in req.body) {
        vals.push(req.body[field] === '' ? null : req.body[field]);
        sets.push(`${field} = $${vals.length}`);
      }
    }
    if (sets.length) {
      vals.push(id);
      await client.query(`UPDATE tickets SET ${sets.join(', ')} WHERE id = $${vals.length}`, vals);
    }

    if (Array.isArray(req.body.tags)) {
      await client.query('DELETE FROM ticket_tags WHERE ticket_id = $1', [id]);
      for (const raw of req.body.tags) {
        const name = String(raw).trim().toLowerCase().slice(0, 40);
        if (!name) continue;
        const tag = await client.query(
          `INSERT INTO tags (name) VALUES ($1)
           ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name RETURNING id`, [name]);
        await client.query(
          'INSERT INTO ticket_tags (ticket_id, tag_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [id, tag.rows[0].id]);
      }
    }

    if (req.body.watchers !== undefined) {
      await client.query('DELETE FROM ticket_watchers WHERE ticket_id = $1', [id]);
      for (const email of parseEmails(req.body.watchers)) {
        const uid = await upsertUserByEmail(client, email);
        await client.query(
          'INSERT INTO ticket_watchers (ticket_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [id, uid]);
      }
    }

    if (req.body.status && req.body.status !== before.status) {
      await client.query(
        `INSERT INTO ticket_events (ticket_id, actor_id, action, detail) VALUES ($1, $2, 'estado', $3)`,
        [id, req.user.id, JSON.stringify({ de: before.status, a: req.body.status })]);
    }
    if (req.body.priority && req.body.priority !== before.priority) {
      await client.query(
        `INSERT INTO ticket_events (ticket_id, actor_id, action, detail) VALUES ($1, $2, 'prioridad', $3)`,
        [id, req.user.id, JSON.stringify({ de: before.priority, a: req.body.priority })]);
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
  notify(req, id);
  res.json(await getTicketDetail(id));
});

router.post('/:id/comments', agent, async (req, res) => {
  const id = Number(req.params.id);
  const body = String(req.body.body || '').trim();
  const internal = Boolean(req.body.is_internal);
  if (!body) return res.status(400).json({ error: 'Escriba un mensaje' });

  const exists = await pool.query('SELECT 1 FROM tickets WHERE id = $1', [id]);
  if (!exists.rowCount) return res.status(404).json({ error: 'Ticket no encontrado' });

  await pool.query(
    'INSERT INTO ticket_comments (ticket_id, author_id, body, is_internal) VALUES ($1, $2, $3, $4)',
    [id, req.user.id, body, internal]
  );
  if (!internal) {
    await pool.query(`UPDATE tickets SET status = 'En progreso' WHERE id = $1 AND status = 'Abierto'`, [id]);
  }
  notify(req, id);
  res.status(201).json(await getTicketDetail(id));
});

router.post('/:id/attachments', agent, upload.array('files', 5), async (req, res) => {
  const id = Number(req.params.id);
  const files = req.files || [];
  const client = await pool.connect();
  try {
    const count = await client.query('SELECT count(*)::int AS n FROM attachments WHERE ticket_id = $1', [id]);
    if (count.rows[0].n + files.length > 5) {
      removeFiles(files);
      return res.status(400).json({ error: 'Un ticket admite un máximo de 5 adjuntos' });
    }
    await client.query('BEGIN');
    await saveAttachments(client, id, req.user.id, files);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    removeFiles(files);
    throw err;
  } finally {
    client.release();
  }
  notify(req, id);
  res.status(201).json(await getTicketDetail(id));
});

router.delete('/:id', agent, async (req, res) => {
  const id = Number(req.params.id);
  const files = await pool.query('SELECT stored_name FROM attachments WHERE ticket_id = $1', [id]);
  const { rowCount } = await pool.query('DELETE FROM tickets WHERE id = $1', [id]);
  if (!rowCount) return res.status(404).json({ error: 'Ticket no encontrado' });
  removeFiles(files.rows.map((f) => f.stored_name));
  notify(req, id);
  res.json({ ok: true });
});

export default router;
