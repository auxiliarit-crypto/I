import cron from 'node-cron';
import { pool } from '../config/db.js';

export function startAutomation(io) {
  cron.schedule('* * * * *', async () => {
    try {
      const days = parseInt(process.env.AUTO_CLOSE_DAYS, 10) || 3;

      const respuesta = await pool.query(
        `UPDATE tickets SET sla_response_breached = true
         WHERE first_response_at IS NULL AND NOT sla_response_breached AND now() > response_due_at
         RETURNING id`);

      const resolucion = await pool.query(
        `UPDATE tickets SET sla_resolution_breached = true
         WHERE resolved_at IS NULL AND NOT sla_resolution_breached AND now() > resolution_due_at
         RETURNING id`);

      const cerrados = await pool.query(
        `UPDATE tickets SET status = 'Cerrado'
         WHERE status = 'Resuelto' AND resolved_at < now() - ($1::int * interval '1 day')
         RETURNING id`, [days]);

      if (cerrados.rows.length) {
        await pool.query(
          `INSERT INTO ticket_events (ticket_id, action, detail)
           SELECT unnest($1::int[]), 'auto_cierre',
                  '{"motivo":"Resuelto sin respuesta del usuario"}'::jsonb`,
          [cerrados.rows.map((r) => r.id)]);
      }

      const changed = [...respuesta.rows, ...resolucion.rows, ...cerrados.rows];
      if (changed.length) {
        io.to('staff').emit('dashboard:refresh');
        for (const r of changed) io.to(`ticket:${r.id}`).emit('ticket:updated', { ticketId: r.id });
        console.log(`[automation] ${respuesta.rowCount} SLA resp., ${resolucion.rowCount} SLA resol., ${cerrados.rowCount} auto-cierres`);
      }
    } catch (err) {
      console.error('[automation] error:', err.message);
    }
  });
}
