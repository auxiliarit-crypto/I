INSERT INTO users (email, full_name, role, is_lead) VALUES
  ('alex.menchu@index.com.gt',   'Alex Menchú',            'agent',    true),
  ('auxiliar.it@index.com.gt',   'Auxiliar de IT',         'agent',    false),
  ('jose.cuevas@index.com.gt',   'José Roberto Cuevas',    'observer', false),
  ('empleado@index.com.gt',      'Empleado Demo',          'end_user', false);

INSERT INTO categories (name, description, default_priority, sort_order) VALUES
  ('Equipo de computo', 'Fallas de PC, laptop, monitor, teclado, mouse',      'Media', 1),
  ('Aspradco',          'Incidencias del sistema Aspradco',                    'Alta',  2),
  ('Cuenta Corriente',  'Problemas con el módulo de Cuenta Corriente',         'Alta',  3),
  ('Ordenes',           'Problemas con órdenes de compra o venta',             'Alta',  4),
  ('SAP',               'Accesos, errores y consultas de SAP',                 'Alta',  5),
  ('Correo',            'Correo electrónico, buzón lleno, accesos',            'Media', 6),
  ('Impresora',         'Impresoras y escáneres',                              'Baja',  7),
  ('Internet',          'Conectividad, WiFi, red',                             'Media', 8),
  ('Otro',              'Cualquier otra solicitud de soporte IT',              'Baja',  9);

INSERT INTO sla_policies (priority, first_response_minutes, resolution_hours) VALUES
  ('Alta',   30,   4),
  ('Media',  120,  24),
  ('Baja',   480,  72);

INSERT INTO tags (name) VALUES ('hardware'), ('software'), ('accesos'), ('urgente'), ('recurrente');

INSERT INTO kb_articles (category_id, title, body) VALUES
  ((SELECT id FROM categories WHERE name = 'Impresora'), 'La impresora no imprime o muestra offline',
   'Verifique que esté encendida y con papel. En Windows abra Dispositivos e impresoras, clic derecho sobre la impresora y desmarque "Usar impresora sin conexión". Reinicie el servicio Cola de impresión (services.msc). Si persiste, apague y encienda la impresora y reintente.'),
  ((SELECT id FROM categories WHERE name = 'Correo'), 'No puedo enviar ni recibir correos',
   'Compruebe que su buzón no esté lleno (elimine correos grandes y vacíe Elementos eliminados). Cierre y abra Outlook. Si cambió su contraseña recientemente, actualícela en Outlook cuando se la solicite.'),
  ((SELECT id FROM categories WHERE name = 'Internet'), 'Sin internet o conexión lenta',
   'Reinicie su equipo. Desconecte y vuelva a conectar el cable de red o el WiFi. Pruebe abrir otra página web. Si otros compañeros tienen el mismo problema, reporte el ticket indicando el área afectada.'),
  ((SELECT id FROM categories WHERE name = 'SAP'), 'SAP no abre o muestra error de inicio de sesión',
   'Verifique que su usuario no esté bloqueado por intentos fallidos. Cierre completamente SAP Logon y vuelva a abrirlo. Si el error indica contraseña expirada, solicite el reinicio de contraseña a IT.'),
  ((SELECT id FROM categories WHERE name = 'Equipo de computo'), 'La computadora está lenta o se congela',
   'Cierre programas que no use, reinicie el equipo y verifique que no tenga actualizaciones pendientes. Si el problema persiste más de un día, abra un ticket indicando el modelo y desde cuándo ocurre.');
