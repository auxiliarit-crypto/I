ALTER DATABASE index_itsm SET timezone TO 'America/Guatemala';
SET timezone TO 'America/Guatemala';

CREATE TYPE user_role       AS ENUM ('agent', 'observer', 'end_user');
CREATE TYPE ticket_status   AS ENUM ('Abierto', 'En progreso', 'Resuelto', 'Cerrado');
CREATE TYPE ticket_priority AS ENUM ('Alta', 'Media', 'Baja');

CREATE TABLE users (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email       text NOT NULL UNIQUE CHECK (email = lower(email)),
  full_name   text NOT NULL,
  role        user_role NOT NULL DEFAULT 'end_user',
  is_lead     boolean NOT NULL DEFAULT false,
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_role ON users(role);

CREATE TABLE categories (
  id               integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name             text NOT NULL UNIQUE,
  description      text NOT NULL DEFAULT '',
  default_priority ticket_priority NOT NULL DEFAULT 'Media',
  active           boolean NOT NULL DEFAULT true,
  sort_order       integer NOT NULL DEFAULT 0
);

CREATE TABLE sla_policies (
  priority               ticket_priority PRIMARY KEY,
  first_response_minutes integer NOT NULL CHECK (first_response_minutes > 0),
  resolution_hours       integer NOT NULL CHECK (resolution_hours > 0)
);

CREATE TABLE tickets (
  id                     integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  status                 ticket_status   NOT NULL DEFAULT 'Abierto',
  priority               ticket_priority NOT NULL DEFAULT 'Media',
  category_id            integer NOT NULL REFERENCES categories(id),
  requester_id           uuid    NOT NULL REFERENCES users(id),
  requester_email        text    NOT NULL,
  assigned_to            uuid    REFERENCES users(id),
  description            text    NOT NULL CHECK (length(btrim(description)) >= 10),
  solution               text,
  created_at             timestamptz NOT NULL DEFAULT now(),
  first_response_at      timestamptz,
  resolved_at            timestamptz,
  closed_at              timestamptz,
  response_due_at        timestamptz,
  resolution_due_at      timestamptz,
  sla_response_breached  boolean NOT NULL DEFAULT false,
  sla_resolution_breached boolean NOT NULL DEFAULT false,
  fcr                    boolean NOT NULL DEFAULT false,
  documented             boolean NOT NULL DEFAULT false,
  csat                   smallint CHECK (csat BETWEEN 1 AND 5),
  response_minutes       integer,
  resolution_hours       numeric(10,2),
  updated_at             timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_tickets_status     ON tickets(status);
CREATE INDEX idx_tickets_priority   ON tickets(priority);
CREATE INDEX idx_tickets_category   ON tickets(category_id);
CREATE INDEX idx_tickets_created    ON tickets(created_at DESC);
CREATE INDEX idx_tickets_requester  ON tickets(requester_id);
CREATE INDEX idx_tickets_assigned   ON tickets(assigned_to);
CREATE INDEX idx_tickets_open       ON tickets(created_at) WHERE status IN ('Abierto', 'En progreso');

CREATE TABLE ticket_comments (
  id          integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  ticket_id   integer NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  author_id   uuid    NOT NULL REFERENCES users(id),
  body        text    NOT NULL CHECK (length(btrim(body)) > 0),
  is_internal boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_comments_ticket ON ticket_comments(ticket_id, created_at);

CREATE TABLE attachments (
  id            integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  ticket_id     integer NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  uploaded_by   uuid    NOT NULL REFERENCES users(id),
  original_name text    NOT NULL,
  stored_name   text    NOT NULL,
  mime_type     text    NOT NULL,
  size_bytes    integer NOT NULL CHECK (size_bytes <= 10485760),
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_attachments_ticket ON attachments(ticket_id);

CREATE TABLE ticket_watchers (
  ticket_id integer NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  user_id   uuid    NOT NULL REFERENCES users(id),
  PRIMARY KEY (ticket_id, user_id)
);

CREATE TABLE tags (
  id   integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name text NOT NULL UNIQUE
);
CREATE TABLE ticket_tags (
  ticket_id integer NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  tag_id    integer NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (ticket_id, tag_id)
);

CREATE TABLE ticket_events (
  id         integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  ticket_id  integer NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  actor_id   uuid REFERENCES users(id),
  action     text NOT NULL,
  detail     jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_events_ticket ON ticket_events(ticket_id, created_at DESC);

CREATE TABLE kb_articles (
  id          integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  category_id integer REFERENCES categories(id),
  title       text NOT NULL,
  body        text NOT NULL,
  active      boolean NOT NULL DEFAULT true
);
CREATE INDEX idx_kb_fts ON kb_articles USING gin (to_tsvector('spanish', title || ' ' || body));

CREATE OR REPLACE FUNCTION fn_ticket_calc() RETURNS trigger AS $$
DECLARE
  pol sla_policies%ROWTYPE;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT * INTO pol FROM sla_policies WHERE priority = NEW.priority;
    NEW.response_due_at   := NEW.created_at + make_interval(mins  => pol.first_response_minutes);
    NEW.resolution_due_at := NEW.created_at + make_interval(hours => pol.resolution_hours);
  ELSE
    IF NEW.priority IS DISTINCT FROM OLD.priority THEN
      SELECT * INTO pol FROM sla_policies WHERE priority = NEW.priority;
      NEW.response_due_at   := NEW.created_at + make_interval(mins  => pol.first_response_minutes);
      NEW.resolution_due_at := NEW.created_at + make_interval(hours => pol.resolution_hours);
    END IF;

    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NEW.status = 'En progreso' AND NEW.first_response_at IS NULL THEN
        NEW.first_response_at := now();
      END IF;
      IF NEW.status IN ('Resuelto', 'Cerrado') THEN
        IF NEW.first_response_at IS NULL THEN NEW.first_response_at := now(); END IF;
        IF NEW.resolved_at IS NULL THEN NEW.resolved_at := now(); END IF;
      END IF;
      IF NEW.status = 'Cerrado' AND NEW.closed_at IS NULL THEN
        NEW.closed_at := now();
      END IF;
      IF NEW.status = 'Resuelto' THEN
        NEW.closed_at := NULL;
      END IF;
      IF NEW.status IN ('Abierto', 'En progreso') THEN
        NEW.resolved_at := NULL;
        NEW.closed_at := NULL;
        NEW.resolution_hours := NULL;
      END IF;
    END IF;
    NEW.updated_at := now();
  END IF;

  IF NEW.first_response_at IS NOT NULL THEN
    NEW.response_minutes := round(extract(epoch FROM (NEW.first_response_at - NEW.created_at)) / 60)::int;
  END IF;
  IF NEW.resolved_at IS NOT NULL THEN
    NEW.resolution_hours := round((extract(epoch FROM (NEW.resolved_at - NEW.created_at)) / 3600)::numeric, 2);
  END IF;

  NEW.sla_response_breached   := COALESCE(NEW.first_response_at, now()) > NEW.response_due_at;
  NEW.sla_resolution_breached := COALESCE(NEW.resolved_at, now())       > NEW.resolution_due_at;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ticket_calc
BEFORE INSERT OR UPDATE ON tickets
FOR EACH ROW EXECUTE FUNCTION fn_ticket_calc();

CREATE OR REPLACE FUNCTION fn_attachments_limit() RETURNS trigger AS $$
BEGIN
  IF (SELECT count(*) FROM attachments WHERE ticket_id = NEW.ticket_id) >= 5 THEN
    RAISE EXCEPTION 'Un ticket admite un máximo de 5 adjuntos';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_attachments_limit
BEFORE INSERT ON attachments
FOR EACH ROW EXECUTE FUNCTION fn_attachments_limit();
