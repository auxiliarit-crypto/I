INSERT INTO tickets (status, priority, category_id, requester_id, requester_email, description, created_at)
SELECT 'Abierto',
       (ARRAY['Alta','Media','Media','Baja'])[1 + floor(random() * 4)::int]::ticket_priority,
       1 + floor(random() * 9)::int,
       (SELECT id FROM users WHERE email = 'empleado@index.com.gt'),
       'empleado@index.com.gt',
       'Ticket de demostración número ' || g || ': el usuario reporta un inconveniente.',
       now() - make_interval(secs => random() * 29 * 86400)
FROM generate_series(1, 45) g;

UPDATE tickets
SET status = 'Resuelto',
    first_response_at = created_at + make_interval(mins => 10 + (id * 7) % 90),
    resolved_at       = created_at + make_interval(hours => 1 + (id * 3) % 30),
    solution = 'Atendido (dato de demostración).',
    fcr = (id % 3 = 0),
    documented = (id % 2 = 0),
    csat = 3 + (id % 3)
WHERE id % 4 <> 0 AND created_at < now() - interval '2 days';

UPDATE tickets SET status = 'Cerrado', closed_at = resolved_at + interval '1 day'
WHERE status = 'Resuelto' AND created_at < now() - interval '7 days';

UPDATE tickets SET status = 'En progreso', first_response_at = created_at + interval '15 minutes'
WHERE status = 'Abierto' AND id % 5 = 0;
